#!/bin/bash
set -euo pipefail
G="/opt/genizah"
echo "=== Genizah v0.5a.1 Deploy ==="
cp backend/src/services/ocr.js "$G/backend/src/services/ocr.js"
cp frontend/src/pages/ScanPage.jsx "$G/frontend/src/pages/ScanPage.jsx"
cd "$G"
docker compose down 2>/dev/null || true
docker compose up -d --build
git add -A
git commit -m "v0.5a.1 - fix OCR totals/vendor, dump raw text to notes" || true
git push origin main || echo "Push failed"
echo ""
echo "=== v0.5a.1 Deployed ==="
echo "New:"
echo "  * Amount: prefers labeled total/credit card over max amount"
echo "  * Vendor: skips garbled lines, requires 40%+ letters"
echo "  * Raw OCR text dumps into Notes field for troubleshooting"
echo ""
