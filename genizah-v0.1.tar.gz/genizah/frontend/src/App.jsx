import { Routes, Route, NavLink, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ScanPage from './pages/ScanPage';
import DocumentPage from './pages/DocumentPage';
import ActivityPage from './pages/ActivityPage';
import { useEffect, useState } from 'react';
import { getSyncStatus } from './services/api';

export default function App() {
  const { user, loading, logout } = useAuth();

  if (loading) return <div className="app-layout"><div className="spinner" /></div>;

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    );
  }

  return (
    <div className="app-layout">
      <TopBar user={user} onLogout={logout} />
      <div className="app-content">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/scan" element={<ScanPage />} />
          <Route path="/doc/:id" element={<DocumentPage />} />
          <Route path="/activity" element={<ActivityPage />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
      <BottomNav />
    </div>
  );
}

function TopBar({ user, onLogout }) {
  const [syncHealth, setSyncHealth] = useState('unknown');

  useEffect(() => {
    getSyncStatus()
      .then(data => setSyncHealth(data.health || 'unknown'))
      .catch(() => setSyncHealth('unknown'));
  }, []);

  return (
    <div className="top-bar">
      <h1>
        GENIZAH
        <span className={`sync-badge sync-${syncHealth}`}
              title={`Backup: ${syncHealth}`} />
      </h1>
      <div className="user-menu" onClick={onLogout}>
        {user.displayName} · Log out
      </div>
    </div>
  );
}

function BottomNav() {
  const navigate = useNavigate();
  return (
    <nav className="bottom-nav">
      <NavLink to="/" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
        <span className="icon">📂</span>
        Docs
      </NavLink>

      <button className="nav-scan" onClick={() => navigate('/scan')}>
        📷
      </button>

      <NavLink to="/activity" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
        <span className="icon">🔔</span>
        Activity
      </NavLink>
    </nav>
  );
}
