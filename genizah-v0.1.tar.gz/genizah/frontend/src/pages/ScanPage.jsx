import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { uploadDocument, getOwners, getTypes } from '../services/api';

export default function ScanPage() {
  const navigate = useNavigate();
  const [owners, setOwners] = useState([]);
  const [types, setTypes] = useState([]);
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [showCamera, setShowCamera] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const fileInputRef = useRef(null);

  // Form state
  const [title, setTitle] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [typeId, setTypeId] = useState('');
  const [documentDate, setDocumentDate] = useState('');
  const [expirationDate, setExpirationDate] = useState('');
  const [amount, setAmount] = useState('');
  const [vendor, setVendor] = useState('');
  const [notes, setNotes] = useState('');
  const [tags, setTags] = useState('');

  useEffect(() => {
    Promise.all([getOwners(), getTypes()])
      .then(([o, t]) => {
        setOwners(o);
        setTypes(t);
        if (o.length > 0) setOwnerId(o[0].id);
        if (t.length > 0) setTypeId(t[0].id);
      })
      .catch(() => {});
  }, []);

  function handleFileSelect(e) {
    const selected = Array.from(e.target.files);
    addFiles(selected);
  }

  function addFiles(newFiles) {
    setFiles(prev => [...prev, ...newFiles]);
    const newPreviews = newFiles.map(f => {
      if (f.type.startsWith('image/')) return URL.createObjectURL(f);
      return null; // PDF, show icon
    });
    setPreviews(prev => [...prev, ...newPreviews]);
  }

  function removeFile(index) {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setPreviews(prev => {
      const url = prev[index];
      if (url) URL.revokeObjectURL(url);
      return prev.filter((_, i) => i !== index);
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (files.length === 0) { setError('Snap a photo or pick a file first'); return; }
    if (!title.trim()) { setError('Give it a title'); return; }
    if (!ownerId) { setError('Pick an owner'); return; }
    if (!typeId) { setError('Pick a document type'); return; }

    setUploading(true);
    setError('');

    try {
      const formData = new FormData();
      files.forEach(f => formData.append('files', f));
      formData.append('title', title.trim());
      formData.append('owner_id', ownerId);
      formData.append('type_id', typeId);
      if (documentDate) formData.append('document_date', documentDate);
      if (expirationDate) formData.append('expiration_date', expirationDate);
      if (amount) formData.append('amount', amount);
      if (vendor.trim()) formData.append('vendor', vendor.trim());
      if (notes.trim()) formData.append('notes', notes.trim());
      if (tags.trim()) {
        const tagList = tags.split(',').map(t => t.trim()).filter(Boolean);
        formData.append('tags', JSON.stringify(tagList));
      }

      const result = await uploadDocument(formData);
      setSuccess(`Uploaded ${result.documents.length} document(s)!`);

      // Reset form
      setFiles([]);
      setPreviews([]);
      setTitle('');
      setDocumentDate('');
      setExpirationDate('');
      setAmount('');
      setVendor('');
      setNotes('');
      setTags('');

      // Go to the document if single
      setTimeout(() => {
        if (result.documents.length === 1) {
          navigate(`/doc/${result.documents[0].id}`);
        } else {
          navigate('/');
        }
      }, 1000);
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  }

  return (
    <>
      <h2 style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: '16px' }}>
        📷 Scan or Upload
      </h2>

      {/* Capture area */}
      <div style={{
        background: 'var(--bg-surface)',
        borderRadius: 'var(--radius-md)',
        border: '2px dashed var(--border)',
        padding: '24px',
        textAlign: 'center',
        marginBottom: '20px'
      }}>
        {previews.length > 0 ? (
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center', marginBottom: '12px' }}>
            {previews.map((url, i) => (
              <div key={i} style={{ position: 'relative' }}>
                {url ? (
                  <img src={url} alt="" style={{
                    width: '80px', height: '80px', objectFit: 'cover',
                    borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)'
                  }} />
                ) : (
                  <div style={{
                    width: '80px', height: '80px', borderRadius: 'var(--radius-sm)',
                    background: 'var(--bg-elevated)', display: 'flex',
                    alignItems: 'center', justifyContent: 'center', fontSize: '2rem'
                  }}>📄</div>
                )}
                <button onClick={() => removeFile(i)} style={{
                  position: 'absolute', top: '-6px', right: '-6px',
                  background: 'var(--accent-red)', color: '#fff',
                  border: 'none', borderRadius: '50%', width: '20px', height: '20px',
                  fontSize: '0.7rem', cursor: 'pointer', lineHeight: '20px'
                }}>✕</button>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ color: 'var(--text-dim)', marginBottom: '12px', fontSize: '2.5rem' }}>📷</div>
        )}

        <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap' }}>
          {/* Camera capture (mobile-first: opens camera directly) */}
          <button
            className="btn btn-primary"
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = 'image/*';
              input.capture = 'environment'; // back camera
              input.onchange = (e) => addFiles(Array.from(e.target.files));
              input.click();
            }}
          >
            📸 Take Photo
          </button>

          {/* File picker */}
          <button className="btn btn-secondary" onClick={() => fileInputRef.current?.click()}>
            📎 Choose File
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,application/pdf"
            multiple
            style={{ display: 'none' }}
            onChange={handleFileSelect}
          />
        </div>
      </div>

      {/* Metadata form */}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title *</label>
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="e.g. State Farm Auto Insurance Card"
            required
          />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div className="form-group">
            <label>Owner *</label>
            <select value={ownerId} onChange={e => setOwnerId(e.target.value)} required>
              {owners.map(o => (
                <option key={o.id} value={o.id}>{o.icon} {o.name}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Type *</label>
            <select value={typeId} onChange={e => setTypeId(e.target.value)} required>
              {types.map(t => (
                <option key={t.id} value={t.id}>{t.icon} {t.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div className="form-group">
            <label>Document Date</label>
            <input type="date" value={documentDate} onChange={e => setDocumentDate(e.target.value)} />
          </div>
          <div className="form-group">
            <label>Expiration Date</label>
            <input type="date" value={expirationDate} onChange={e => setExpirationDate(e.target.value)} />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          <div className="form-group">
            <label>Amount ($)</label>
            <input
              type="number"
              step="0.01"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="0.00"
            />
          </div>
          <div className="form-group">
            <label>Vendor / Source</label>
            <input
              type="text"
              value={vendor}
              onChange={e => setVendor(e.target.value)}
              placeholder="e.g. State Farm"
            />
          </div>
        </div>

        <div className="form-group">
          <label>Tags (comma separated)</label>
          <input
            type="text"
            value={tags}
            onChange={e => setTags(e.target.value)}
            placeholder="e.g. 2026 taxes, auto, insurance"
          />
        </div>

        <div className="form-group">
          <label>Notes</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="Any extra notes about this document..."
            rows={3}
          />
        </div>

        {error && (
          <div style={{
            background: 'rgba(255,87,87,0.1)', border: '1px solid rgba(255,87,87,0.3)',
            borderRadius: 'var(--radius-sm)', padding: '10px 14px', marginBottom: '16px',
            fontSize: '0.85rem', color: 'var(--accent-red)'
          }}>{error}</div>
        )}

        {success && (
          <div style={{
            background: 'rgba(58,217,142,0.1)', border: '1px solid rgba(58,217,142,0.3)',
            borderRadius: 'var(--radius-sm)', padding: '10px 14px', marginBottom: '16px',
            fontSize: '0.85rem', color: 'var(--accent-green)'
          }}>{success}</div>
        )}

        <button type="submit" className="btn btn-primary btn-block" disabled={uploading || files.length === 0}>
          {uploading ? 'Uploading...' : `📤 Upload ${files.length > 0 ? `(${files.length} file${files.length > 1 ? 's' : ''})` : ''}`}
        </button>
      </form>
    </>
  );
}
