import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getDocument, updateDocument, deleteDocument, getOwners, getTypes } from '../services/api';

export default function DocumentPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [doc, setDoc] = useState(null);
  const [owners, setOwners] = useState([]);
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showOcr, setShowOcr] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [toast, setToast] = useState('');

  // Edit form state
  const [editTitle, setEditTitle] = useState('');
  const [editOwnerId, setEditOwnerId] = useState('');
  const [editTypeId, setEditTypeId] = useState('');
  const [editDocDate, setEditDocDate] = useState('');
  const [editExpDate, setEditExpDate] = useState('');
  const [editAmount, setEditAmount] = useState('');
  const [editVendor, setEditVendor] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editTags, setEditTags] = useState('');
  const [editStatus, setEditStatus] = useState('');

  useEffect(() => {
    Promise.all([getDocument(id), getOwners(), getTypes()])
      .then(([d, o, t]) => {
        setDoc(d);
        setOwners(o);
        setTypes(t);
        populateEdit(d);
      })
      .catch(err => { console.error(err); navigate('/'); })
      .finally(() => setLoading(false));
  }, [id]);

  function populateEdit(d) {
    setEditTitle(d.title || '');
    setEditOwnerId(d.owner_id || '');
    setEditTypeId(d.type_id || '');
    setEditDocDate(d.document_date ? d.document_date.slice(0, 10) : '');
    setEditExpDate(d.expiration_date ? d.expiration_date.slice(0, 10) : '');
    setEditAmount(d.amount != null ? String(d.amount) : '');
    setEditVendor(d.vendor || '');
    setEditNotes(d.notes || '');
    setEditTags(d.tags ? d.tags.join(', ') : '');
    setEditStatus(d.status || 'active');
  }

  async function handleSave() {
    setSaving(true);
    try {
      const tagList = editTags.split(',').map(t => t.trim()).filter(Boolean);
      const updated = await updateDocument(id, {
        title: editTitle,
        owner_id: editOwnerId,
        type_id: editTypeId,
        document_date: editDocDate || null,
        expiration_date: editExpDate || null,
        amount: editAmount ? parseFloat(editAmount) : null,
        vendor: editVendor || null,
        notes: editNotes || null,
        status: editStatus,
        tags: tagList
      });
      // Reload full doc to get joined fields
      const fresh = await getDocument(id);
      setDoc(fresh);
      populateEdit(fresh);
      setEditing(false);
      showToast('Saved!');
    } catch (err) {
      showToast(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    try {
      await deleteDocument(id);
      navigate('/');
    } catch (err) {
      showToast(err.message);
    }
  }

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  }

  function formatDate(dateStr) {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }

  if (loading) return <div className="spinner" />;
  if (!doc) return null;

  const isImage = doc.mime_type?.startsWith('image/');

  return (
    <>
      {/* Back button */}
      <button className="btn btn-ghost" onClick={() => navigate(-1)} style={{ marginBottom: '12px' }}>
        ← Back
      </button>

      {/* Document preview */}
      <div style={{
        background: 'var(--bg-surface)',
        borderRadius: 'var(--radius-md)',
        overflow: 'hidden',
        marginBottom: '16px',
        border: '1px solid var(--border)'
      }}>
        {isImage ? (
          <img
            src={`/files/${doc.file_path}`}
            alt={doc.title}
            style={{ width: '100%', maxHeight: '400px', objectFit: 'contain', background: '#000' }}
          />
        ) : (
          <div style={{
            height: '200px', display: 'flex', alignItems: 'center',
            justifyContent: 'center', background: 'var(--bg-elevated)'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem' }}>📄</div>
              <a href={`/files/${doc.file_path}`} target="_blank" rel="noopener"
                className="btn btn-secondary" style={{ marginTop: '12px' }}>
                Open PDF
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Info or Edit mode */}
      {!editing ? (
        <div className="card">
          <h2 style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: '12px' }}>{doc.title}</h2>

          <InfoRow label="Owner">
            <span className="owner-badge" style={{
              background: `${doc.owner_color}20`, color: doc.owner_color
            }}>
              {doc.owner_icon} {doc.owner_name}
            </span>
          </InfoRow>
          <InfoRow label="Type">{doc.type_icon} {doc.type_name}</InfoRow>
          <InfoRow label="Status">
            <span className={`status-badge status-${doc.status}`}>{doc.status}</span>
          </InfoRow>
          <InfoRow label="Uploaded">{formatDate(doc.submitted_at)} by {doc.uploaded_by_name}</InfoRow>
          <InfoRow label="Document Date">{formatDate(doc.document_date)}</InfoRow>
          {doc.expiration_date && <InfoRow label="Expires">{formatDate(doc.expiration_date)}</InfoRow>}
          {doc.amount != null && <InfoRow label="Amount">${Number(doc.amount).toFixed(2)}</InfoRow>}
          {doc.vendor && <InfoRow label="Vendor">{doc.vendor}</InfoRow>}
          {doc.notes && <InfoRow label="Notes">{doc.notes}</InfoRow>}
          {doc.tags && doc.tags.length > 0 && (
            <InfoRow label="Tags">
              {doc.tags.map(t => (
                <span key={t} style={{
                  background: 'var(--bg-input)', padding: '2px 8px',
                  borderRadius: '4px', fontSize: '0.8rem', marginRight: '4px'
                }}>{t}</span>
              ))}
            </InfoRow>
          )}

          {/* OCR text toggle */}
          {doc.ocr_text && (
            <div style={{ marginTop: '12px' }}>
              <button className="btn btn-ghost" onClick={() => setShowOcr(!showOcr)}
                style={{ fontSize: '0.8rem', padding: '4px 8px' }}>
                {showOcr ? '▼' : '▶'} OCR Text ({doc.ocr_status})
              </button>
              {showOcr && (
                <pre style={{
                  background: 'var(--bg-input)', padding: '12px',
                  borderRadius: 'var(--radius-sm)', marginTop: '8px',
                  fontSize: '0.78rem', color: 'var(--text-secondary)',
                  whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                  maxHeight: '300px', overflowY: 'auto'
                }}>
                  {doc.ocr_text}
                </pre>
              )}
            </div>
          )}

          {/* Actions */}
          <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
            <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => setEditing(true)}>
              ✏️ Edit
            </button>
            {!confirmDelete ? (
              <button className="btn btn-danger" style={{ flex: 1 }} onClick={() => setConfirmDelete(true)}>
                🗑️ Delete
              </button>
            ) : (
              <button className="btn btn-danger" style={{ flex: 1 }} onClick={handleDelete}>
                Confirm Delete?
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Edit mode */
        <div className="card">
          <h3 style={{ marginBottom: '16px' }}>Edit Document</h3>

          <div className="form-group">
            <label>Title</label>
            <input type="text" value={editTitle} onChange={e => setEditTitle(e.target.value)} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div className="form-group">
              <label>Owner</label>
              <select value={editOwnerId} onChange={e => setEditOwnerId(e.target.value)}>
                {owners.map(o => <option key={o.id} value={o.id}>{o.icon} {o.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Type</label>
              <select value={editTypeId} onChange={e => setEditTypeId(e.target.value)}>
                {types.map(t => <option key={t.id} value={t.id}>{t.icon} {t.name}</option>)}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label>Status</label>
            <select value={editStatus} onChange={e => setEditStatus(e.target.value)}>
              <option value="active">Active</option>
              <option value="expired">Expired</option>
              <option value="archived">Archived</option>
            </select>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div className="form-group">
              <label>Document Date</label>
              <input type="date" value={editDocDate} onChange={e => setEditDocDate(e.target.value)} />
            </div>
            <div className="form-group">
              <label>Expiration</label>
              <input type="date" value={editExpDate} onChange={e => setEditExpDate(e.target.value)} />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div className="form-group">
              <label>Amount ($)</label>
              <input type="number" step="0.01" value={editAmount} onChange={e => setEditAmount(e.target.value)} />
            </div>
            <div className="form-group">
              <label>Vendor</label>
              <input type="text" value={editVendor} onChange={e => setEditVendor(e.target.value)} />
            </div>
          </div>

          <div className="form-group">
            <label>Tags (comma separated)</label>
            <input type="text" value={editTags} onChange={e => setEditTags(e.target.value)} />
          </div>

          <div className="form-group">
            <label>Notes</label>
            <textarea value={editNotes} onChange={e => setEditNotes(e.target.value)} rows={3} />
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button className="btn btn-primary" style={{ flex: 1 }} onClick={handleSave} disabled={saving}>
              {saving ? 'Saving...' : '💾 Save'}
            </button>
            <button className="btn btn-secondary" style={{ flex: 1 }} onClick={() => { setEditing(false); populateEdit(doc); }}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </>
  );
}

function InfoRow({ label, children }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,0.04)',
      fontSize: '0.88rem'
    }}>
      <span style={{ color: 'var(--text-dim)', fontWeight: 500 }}>{label}</span>
      <span>{children}</span>
    </div>
  );
}
