import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { getDocuments, getOwners, getTypes } from '../services/api';

export default function DashboardPage() {
  const navigate = useNavigate();
  const [documents, setDocuments] = useState([]);
  const [owners, setOwners] = useState([]);
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterOwner, setFilterOwner] = useState('');
  const [filterType, setFilterType] = useState('');
  const [pagination, setPagination] = useState({ page: 1, total: 0, totalPages: 0 });

  const loadDocs = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getDocuments({
        search: search || undefined,
        owner_id: filterOwner || undefined,
        type_id: filterType || undefined,
        page: pagination.page,
        limit: 20
      });
      setDocuments(data.documents);
      setPagination(data.pagination);
    } catch (err) {
      console.error('Failed to load documents:', err);
    } finally {
      setLoading(false);
    }
  }, [search, filterOwner, filterType, pagination.page]);

  useEffect(() => {
    Promise.all([getOwners(), getTypes()])
      .then(([o, t]) => { setOwners(o); setTypes(t); })
      .catch(() => {});
  }, []);

  useEffect(() => { loadDocs(); }, [loadDocs]);

  // Debounced search
  const [searchInput, setSearchInput] = useState('');
  useEffect(() => {
    const timer = setTimeout(() => setSearch(searchInput), 300);
    return () => clearTimeout(timer);
  }, [searchInput]);

  function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }

  return (
    <>
      {/* Search */}
      <div className="search-bar">
        <span className="search-icon">🔍</span>
        <input
          type="text"
          placeholder="Search documents, vendors, notes..."
          value={searchInput}
          onChange={e => { setSearchInput(e.target.value); setPagination(p => ({ ...p, page: 1 })); }}
        />
      </div>

      {/* Owner filter chips */}
      <div className="filter-row">
        <button
          className={`chip ${filterOwner === '' ? 'active' : ''}`}
          onClick={() => { setFilterOwner(''); setPagination(p => ({ ...p, page: 1 })); }}
        >
          All
        </button>
        {owners.map(o => (
          <button
            key={o.id}
            className={`chip ${filterOwner === o.id ? 'active' : ''}`}
            onClick={() => { setFilterOwner(filterOwner === o.id ? '' : o.id); setPagination(p => ({ ...p, page: 1 })); }}
            style={filterOwner === o.id ? {} : { borderColor: o.color, color: o.color }}
          >
            {o.icon} {o.name}
          </button>
        ))}
      </div>

      {/* Type filter (collapsible, optional) */}
      {types.length > 0 && (
        <div className="filter-row">
          <button
            className={`chip ${filterType === '' ? 'active' : ''}`}
            onClick={() => { setFilterType(''); setPagination(p => ({ ...p, page: 1 })); }}
          >
            All Types
          </button>
          {types.map(t => (
            <button
              key={t.id}
              className={`chip ${filterType === t.id ? 'active' : ''}`}
              onClick={() => { setFilterType(filterType === t.id ? '' : t.id); setPagination(p => ({ ...p, page: 1 })); }}
            >
              {t.icon} {t.name}
            </button>
          ))}
        </div>
      )}

      {/* Results count */}
      <div style={{ fontSize: '0.78rem', color: 'var(--text-dim)', marginBottom: '12px' }}>
        {pagination.total} document{pagination.total !== 1 ? 's' : ''}
        {search && ` matching "${search}"`}
      </div>

      {/* Document list */}
      {loading ? (
        <div className="spinner" />
      ) : documents.length === 0 ? (
        <div className="empty-state">
          <div className="icon">📁</div>
          <p>{search ? 'No documents match your search' : 'No documents yet'}</p>
          {!search && (
            <button className="btn btn-primary" onClick={() => navigate('/scan')}>
              📷 Scan your first document
            </button>
          )}
        </div>
      ) : (
        <>
          {documents.map(doc => (
            <div key={doc.id} className="card doc-card" onClick={() => navigate(`/doc/${doc.id}`)}>
              <div className="thumb">
                {doc.thumbnail_path
                  ? <img src={`/thumbnails/${doc.thumbnail_path}`} alt="" loading="lazy" />
                  : doc.type_icon || '📄'
                }
              </div>
              <div className="info">
                <div className="title">{doc.title}</div>
                <div className="meta">
                  <span className="owner-badge" style={{
                    background: `${doc.owner_color}20`,
                    color: doc.owner_color
                  }}>
                    {doc.owner_icon} {doc.owner_name}
                  </span>
                  {' · '}
                  {doc.type_name}
                  {doc.amount ? ` · $${Number(doc.amount).toFixed(2)}` : ''}
                </div>
                <div className="meta">
                  {formatDate(doc.submitted_at)}
                  {doc.vendor && ` · ${doc.vendor}`}
                  {doc.status !== 'active' && (
                    <span className={`status-badge status-${doc.status}`} style={{ marginLeft: '6px' }}>
                      {doc.status}
                    </span>
                  )}
                </div>
                {doc.tags && doc.tags.length > 0 && (
                  <div className="meta" style={{ marginTop: '4px' }}>
                    {doc.tags.map(t => (
                      <span key={t} style={{
                        background: 'var(--bg-input)',
                        padding: '1px 6px',
                        borderRadius: '4px',
                        fontSize: '0.7rem',
                        marginRight: '4px'
                      }}>{t}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '16px' }}>
              <button
                className="btn btn-secondary"
                disabled={pagination.page <= 1}
                onClick={() => setPagination(p => ({ ...p, page: p.page - 1 }))}
              >
                ← Prev
              </button>
              <span style={{ display: 'flex', alignItems: 'center', color: 'var(--text-dim)', fontSize: '0.85rem' }}>
                {pagination.page} / {pagination.totalPages}
              </span>
              <button
                className="btn btn-secondary"
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => setPagination(p => ({ ...p, page: p.page + 1 }))}
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </>
  );
}
