#!/bin/bash
# Genizah — Google Drive encrypted sync
# Runs via cron every 6 hours:
#   0 */6 * * * /opt/genizah/config/rclone-sync.sh >> /var/log/genizah-sync.log 2>&1
#
# Prerequisites:
#   1. rclone configured with a Google Drive remote named "gdrive"
#   2. rclone crypt remote named "gdrive-crypt" layered on top
#      rclone config:
#        [gdrive]        type = drive
#        [gdrive-crypt]  type = crypt, remote = gdrive:genizah-vault
#   3. curl available for reporting sync status to the app

set -euo pipefail

GENIZAH_DIR="/opt/genizah"
FILES_DIR="${GENIZAH_DIR}/files"
DB_DIR="${GENIZAH_DIR}/db"
DB_FILE="${DB_DIR}/genizah.sqlite"
BACKUP_DIR="${GENIZAH_DIR}/backups"
RCLONE_REMOTE="gdrive-crypt:genizah"
API_URL="http://127.0.0.1:3090/api/sync/report"
STARTED_AT=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "=== Genizah sync started at $(date) ==="

mkdir -p "${BACKUP_DIR}"

# Step 1: Backup SQLite database before sync
echo "Backing up SQLite database..."
sqlite3 "${DB_FILE}" ".backup '${BACKUP_DIR}/genizah-backup.sqlite'"
echo "Database backup complete"

# Step 2: Sync files to encrypted Google Drive
echo "Syncing files to Google Drive (encrypted)..."
if rclone sync "${FILES_DIR}" "${RCLONE_REMOTE}/files/" \
  --drive-use-trash=false \
  --transfers 4 \
  --checkers 8 \
  --log-level INFO \
  --stats-one-line; then

  # Also sync the database backup
  rclone copy "${BACKUP_DIR}/genizah-backup.sqlite" "${RCLONE_REMOTE}/db/" \
    --drive-use-trash=false

  # Count files and total size
  FILE_COUNT=$(find "${FILES_DIR}" -type f | wc -l)
  TOTAL_SIZE=$(du -sb "${FILES_DIR}" | cut -f1)

  echo "Sync complete: ${FILE_COUNT} files, ${TOTAL_SIZE} bytes"

  # Report success to Genizah API
  curl -s -X POST "${API_URL}" \
    -H "Content-Type: application/json" \
    -d "{\"status\":\"success\",\"file_count\":${FILE_COUNT},\"total_size_bytes\":${TOTAL_SIZE},\"started_at\":\"${STARTED_AT}\"}" \
    || echo "Warning: Could not report sync status to API"

else
  ERROR_MSG="rclone sync failed with exit code $?"
  echo "ERROR: ${ERROR_MSG}"

  # Report failure
  curl -s -X POST "${API_URL}" \
    -H "Content-Type: application/json" \
    -d "{\"status\":\"failed\",\"error_message\":\"${ERROR_MSG}\",\"started_at\":\"${STARTED_AT}\"}" \
    || echo "Warning: Could not report sync failure to API"

  # Send Ntfy alert on failure
  curl -s \
    -H "Title: Genizah Sync Failed" \
    -H "Priority: urgent" \
    -H "Tags: rotating_light" \
    -d "Google Drive sync failed at $(date). Check /var/log/genizah-sync.log" \
    "http://127.0.0.1:8090/genizah" \
    || true
fi

echo "=== Genizah sync finished at $(date) ==="
