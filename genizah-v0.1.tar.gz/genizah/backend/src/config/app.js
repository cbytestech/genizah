// Genizah — Express app setup

const express = require('express');
const cors = require('cors');
const path = require('path');

function createApp() {
  const app = express();

  // Middleware
  app.use(cors({
    origin: process.env.NODE_ENV === 'production'
      ? 'https://vault.cookiebytestech.com'
      : ['http://localhost:5173', 'http://localhost:3090'],
    credentials: true
  }));
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // API routes
  app.use('/api/auth', require('../routes/auth'));
  app.use('/api/documents', require('../routes/documents'));
  app.use('/api/owners', require('../routes/owners'));
  app.use('/api/types', require('../routes/types'));
  app.use('/api/tags', require('../routes/tags'));
  app.use('/api/activity', require('../routes/activity'));
  app.use('/api/sync', require('../routes/sync'));

  // Serve uploaded files (authenticated)
  const { authenticate } = require('../middleware/auth');
  app.use('/files', authenticate, express.static(
    process.env.UPLOAD_PATH || path.join(__dirname, '../../data/files')
  ));
  app.use('/thumbnails', authenticate, express.static(
    process.env.THUMBNAIL_PATH || path.join(__dirname, '../../data/thumbnails')
  ));

  // Serve React PWA (production)
  const publicPath = path.join(__dirname, '../public');
  app.use(express.static(publicPath));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api/') && !req.path.startsWith('/files/') && !req.path.startsWith('/thumbnails/')) {
      res.sendFile(path.join(publicPath, 'index.html'));
    }
  });

  // Error handler
  app.use((err, req, res, next) => {
    console.error(`[Genizah Error] ${err.message}`, err.stack);
    res.status(err.status || 500).json({
      error: err.message || 'Internal server error',
      ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
    });
  });

  return app;
}

module.exports = { createApp };
