// Genizah — Database initialization and schema
// Uses better-sqlite3 for synchronous, simple SQLite access.

const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../../data/db/genizah.sqlite');

let db;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    initSchema();
  }
  return db;
}

function initSchema() {
  db.exec(`
    -- Users (Norm, Emily, future expansion)
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      display_name TEXT NOT NULL,
      password_hash TEXT,                    -- null if SSO-only
      auth_method TEXT DEFAULT 'local',      -- 'local' | 'authentik' | 'both'
      authentik_sub TEXT UNIQUE,             -- Authentik subject ID for SSO
      role TEXT DEFAULT 'user',              -- 'admin' | 'user'
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Owners (who/what the document belongs to)
    CREATE TABLE IF NOT EXISTS owners (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,             -- Homestead, CBT, Emily, Norm
      color TEXT,                            -- hex color for UI badges
      icon TEXT,                             -- emoji or icon name
      sort_order INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Document types
    CREATE TABLE IF NOT EXISTS document_types (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,             -- Receipt, Letter, Manual, Invoice, etc.
      icon TEXT,
      sort_order INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Documents (core table)
    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      owner_id TEXT NOT NULL REFERENCES owners(id),
      type_id TEXT NOT NULL REFERENCES document_types(id),
      status TEXT DEFAULT 'active',          -- active | expired | archived

      -- Dates
      submitted_at TEXT DEFAULT (datetime('now')),  -- when uploaded
      document_date TEXT,                    -- date on the document itself
      expiration_date TEXT,                  -- renewal/expiration (nullable)

      -- Financial
      amount REAL,                           -- dollar amount (receipts, invoices)
      vendor TEXT,                           -- who issued it

      -- Content
      notes TEXT,                            -- freeform notes
      ocr_text TEXT,                         -- extracted text from Sofer
      ocr_status TEXT DEFAULT 'pending',     -- pending | processing | complete | failed

      -- File info
      original_filename TEXT,
      file_path TEXT NOT NULL,               -- relative path in /files/
      thumbnail_path TEXT,                   -- relative path in /thumbnails/
      mime_type TEXT,
      file_size INTEGER,                     -- bytes
      page_count INTEGER DEFAULT 1,

      -- Magen integration
      magen_shared BOOLEAN DEFAULT 0,        -- shared from Magen
      magen_ref TEXT,                         -- reference ID in Magen (nullable)

      -- Metadata
      uploaded_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    -- Tags (freeform labels)
    CREATE TABLE IF NOT EXISTS tags (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Document-tag junction
    CREATE TABLE IF NOT EXISTS document_tags (
      document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
      tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
      PRIMARY KEY (document_id, tag_id)
    );

    -- Activity log (notifications feed)
    CREATE TABLE IF NOT EXISTS activity_log (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      document_id TEXT REFERENCES documents(id) ON DELETE SET NULL,
      action TEXT NOT NULL,                  -- uploaded | viewed | edited | deleted | shared | expired_warning
      detail TEXT,                           -- human-readable summary
      notified BOOLEAN DEFAULT 0,            -- has Ntfy been sent?
      created_at TEXT DEFAULT (datetime('now'))
    );

    -- Sync status tracking
    CREATE TABLE IF NOT EXISTS sync_status (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sync_type TEXT NOT NULL,               -- gdrive | backup
      status TEXT NOT NULL,                  -- success | failed
      file_count INTEGER,
      total_size_bytes INTEGER,
      error_message TEXT,
      started_at TEXT,
      completed_at TEXT DEFAULT (datetime('now'))
    );

    -- Indexes
    CREATE INDEX IF NOT EXISTS idx_documents_owner ON documents(owner_id);
    CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type_id);
    CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
    CREATE INDEX IF NOT EXISTS idx_documents_submitted ON documents(submitted_at);
    CREATE INDEX IF NOT EXISTS idx_documents_expiration ON documents(expiration_date);
    CREATE INDEX IF NOT EXISTS idx_documents_uploaded_by ON documents(uploaded_by);
    CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_log(user_id);
    CREATE INDEX IF NOT EXISTS idx_activity_document ON activity_log(document_id);
    CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_log(created_at);
    CREATE INDEX IF NOT EXISTS idx_documents_fts ON documents(ocr_text);
  `);

  // Seed default owners
  const insertOwner = db.prepare(`
    INSERT OR IGNORE INTO owners (id, name, color, icon, sort_order)
    VALUES (?, ?, ?, ?, ?)
  `);
  insertOwner.run('owner-homestead', 'Homestead', '#3ad98e', '🏠', 1);
  insertOwner.run('owner-cbt', 'CBT', '#4a9eff', '🍪', 2);
  insertOwner.run('owner-emily', 'Emily', '#e88aed', '👩', 3);
  insertOwner.run('owner-norm', 'Norm', '#f77f3a', '👨', 4);

  // Seed default document types
  const insertType = db.prepare(`
    INSERT OR IGNORE INTO document_types (id, name, icon, sort_order)
    VALUES (?, ?, ?, ?)
  `);
  insertType.run('type-receipt', 'Receipt', '🧾', 1);
  insertType.run('type-letter', 'Letter', '✉️', 2);
  insertType.run('type-manual', 'Manual', '📖', 3);
  insertType.run('type-invoice', 'Invoice', '📄', 4);
  insertType.run('type-certificate', 'Certificate', '📜', 5);
  insertType.run('type-policy', 'Policy', '🛡️', 6);
  insertType.run('type-title', 'Title', '📋', 7);
  insertType.run('type-license', 'License', '🪪', 8);
  insertType.run('type-statement', 'Statement', '🏦', 9);
  insertType.run('type-contract', 'Contract', '📝', 10);
  insertType.run('type-warranty', 'Warranty', '🔧', 11);
  insertType.run('type-tax-form', 'Tax Form', '🏛️', 12);
  insertType.run('type-medical', 'Medical Record', '🏥', 13);
  insertType.run('type-id-document', 'ID Document', '🆔', 14);
  insertType.run('type-photo', 'Photo/Image', '📸', 15);
  insertType.run('type-other', 'Other', '📁', 99);
}

function closeDb() {
  if (db) {
    db.close();
    db = null;
  }
}

module.exports = { getDb, closeDb };
