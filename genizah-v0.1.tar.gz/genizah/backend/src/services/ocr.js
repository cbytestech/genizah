// Genizah — OCR service
// Sends documents to Sofer (Paperless-ngx) for text extraction.
// Same pattern as the Stocked receipt scanner.

const fs = require('fs');
const path = require('path');

const SOFER_BASE = process.env.SOFER_BASE_URL || 'http://127.0.0.1:8010';
const SOFER_TOKEN = process.env.SOFER_API_TOKEN;

// Submit a document for OCR and store the extracted text
async function submitForOcr(documentId, filePath, mimeType) {
  if (!SOFER_TOKEN) {
    console.warn('[Genizah] Sofer API token not configured, skipping OCR');
    updateOcrStatus(documentId, 'failed', null);
    return;
  }

  try {
    updateOcrStatus(documentId, 'processing', null);

    // Step 1: Upload to Paperless-ngx
    const fileBuffer = fs.readFileSync(filePath);
    const filename = path.basename(filePath);

    const formData = new FormData();
    formData.append('document', new Blob([fileBuffer], { type: mimeType }), filename);
    formData.append('title', `genizah-${documentId}`);

    const uploadRes = await fetch(`${SOFER_BASE}/api/documents/post_document/`, {
      method: 'POST',
      headers: { Authorization: `Token ${SOFER_TOKEN}` },
      body: formData
    });

    if (!uploadRes.ok) {
      const errText = await uploadRes.text();
      throw new Error(`Sofer upload failed (${uploadRes.status}): ${errText}`);
    }

    // Response is a task ID (UUID string)
    const taskId = await uploadRes.text();

    // Step 2: Poll for completion
    const ocrText = await pollForResult(taskId.replace(/"/g, ''), documentId);

    // Step 3: Store OCR text
    updateOcrStatus(documentId, 'complete', ocrText);

    console.log(`[Genizah] OCR complete for ${documentId}: ${ocrText.length} chars extracted`);
  } catch (err) {
    console.error(`[Genizah] OCR error for ${documentId}:`, err.message);
    updateOcrStatus(documentId, 'failed', null);
  }
}

// Poll Paperless task until complete
async function pollForResult(taskId, documentId, maxAttempts = 30) {
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(resolve => setTimeout(resolve, 3000)); // 3s intervals

    const taskRes = await fetch(`${SOFER_BASE}/api/tasks/?task_id=${taskId}`, {
      headers: { Authorization: `Token ${SOFER_TOKEN}` }
    });

    if (!taskRes.ok) continue;

    const tasks = await taskRes.json();
    if (!tasks || tasks.length === 0) continue;

    const task = tasks[0];

    if (task.status === 'SUCCESS' && task.related_document) {
      // Fetch the document content from Paperless
      const docRes = await fetch(`${SOFER_BASE}/api/documents/${task.related_document}/`, {
        headers: { Authorization: `Token ${SOFER_TOKEN}` }
      });

      if (docRes.ok) {
        const doc = await docRes.json();
        return doc.content || '';
      }
    }

    if (task.status === 'FAILURE') {
      throw new Error(`Sofer task failed: ${task.result || 'unknown error'}`);
    }
  }

  throw new Error('OCR polling timed out');
}

function updateOcrStatus(documentId, status, text) {
  try {
    const { getDb } = require('../models/database');
    const db = getDb();
    db.prepare(`
      UPDATE documents SET ocr_status = ?, ocr_text = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(status, text, documentId);
  } catch (err) {
    console.error(`[Genizah] Failed to update OCR status for ${documentId}:`, err.message);
  }
}

module.exports = { submitForOcr };
