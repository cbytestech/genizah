// Genizah — Document routes
// POST   /api/documents          Upload document(s)
// GET    /api/documents          List/search documents
// GET    /api/documents/:id      Get single document
// PATCH  /api/documents/:id      Update metadata
// DELETE /api/documents/:id      Delete document

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../models/database');
const { authenticate } = require('../middleware/auth');
const { generateThumbnail } = require('../services/thumbnails');
const { submitForOcr } = require('../services/ocr');
const { logActivity, notifyUsers } = require('../services/notifications');

const router = express.Router();
router.use(authenticate);

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = process.env.UPLOAD_PATH || path.join(__dirname, '../../data/files');
    const yearMonth = new Date().toISOString().slice(0, 7); // 2026-08
    const dest = path.join(uploadPath, yearMonth);
    fs.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: (parseInt(process.env.MAX_FILE_SIZE_MB) || 25) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = [
      'image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif',
      'application/pdf'
    ];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${file.mimetype} not allowed. Accepted: JPG, PNG, WebP, HEIC, PDF`));
    }
  }
});

// Upload document
router.post('/', upload.array('files', 10), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const {
      title, owner_id, type_id, document_date,
      expiration_date, amount, vendor, notes, tags,
      magen_shared, magen_ref
    } = req.body;

    if (!title || !owner_id || !type_id) {
      return res.status(400).json({ error: 'title, owner_id, and type_id are required' });
    }

    const db = getDb();
    const documents = [];

    for (const file of req.files) {
      const id = uuidv4();
      const uploadBase = process.env.UPLOAD_PATH || path.join(__dirname, '../../data/files');
      const relativePath = path.relative(uploadBase, file.path);

      // Generate thumbnail
      const thumbRelPath = await generateThumbnail(file.path, id, file.mimetype);

      // Determine title: use provided title, append index if multiple files
      const docTitle = req.files.length > 1
        ? `${title} (${documents.length + 1})`
        : title;

      db.prepare(`
        INSERT INTO documents (
          id, title, owner_id, type_id, status,
          document_date, expiration_date, amount, vendor, notes,
          original_filename, file_path, thumbnail_path, mime_type, file_size, page_count,
          magen_shared, magen_ref, uploaded_by
        ) VALUES (?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
      `).run(
        id, docTitle, owner_id, type_id,
        document_date || null, expiration_date || null,
        amount ? parseFloat(amount) : null, vendor || null, notes || null,
        file.originalname, relativePath, thumbRelPath, file.mimetype, file.size,
        magen_shared === 'true' ? 1 : 0, magen_ref || null,
        req.user.id
      );

      // Apply tags
      if (tags) {
        const tagList = typeof tags === 'string' ? JSON.parse(tags) : tags;
        applyTags(db, id, tagList);
      }

      // Submit for OCR (async, non-blocking)
      submitForOcr(id, file.path, file.mimetype).catch(err => {
        console.error(`[Genizah] OCR failed for ${id}:`, err.message);
      });

      // Log activity
      logActivity(req.user.id, id, 'uploaded', `${req.user.displayName} uploaded "${docTitle}"`);

      documents.push({ id, title: docTitle, file_path: relativePath });
    }

    // Notify other users
    notifyUsers(req.user, 'uploaded', documents.length === 1
      ? `📄 ${req.user.displayName} uploaded "${title}"`
      : `📄 ${req.user.displayName} uploaded ${documents.length} documents`
    );

    res.status(201).json({ documents });
  } catch (err) {
    console.error('[Genizah] Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// List/search documents
router.get('/', (req, res) => {
  const {
    owner_id, type_id, status, search,
    date_from, date_to, sort, order,
    page, limit
  } = req.query;

  const db = getDb();
  const conditions = [];
  const params = [];

  if (owner_id) { conditions.push('d.owner_id = ?'); params.push(owner_id); }
  if (type_id) { conditions.push('d.type_id = ?'); params.push(type_id); }
  if (status) { conditions.push('d.status = ?'); params.push(status); }
  else { conditions.push("d.status != 'archived'"); } // default: hide archived

  if (date_from) { conditions.push('d.submitted_at >= ?'); params.push(date_from); }
  if (date_to) { conditions.push('d.submitted_at <= ?'); params.push(date_to); }

  if (search) {
    conditions.push('(d.title LIKE ? OR d.ocr_text LIKE ? OR d.vendor LIKE ? OR d.notes LIKE ?)');
    const term = `%${search}%`;
    params.push(term, term, term, term);
  }

  const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  const sortCol = ['submitted_at', 'document_date', 'title', 'amount', 'expiration_date'].includes(sort) ? sort : 'submitted_at';
  const sortDir = order === 'asc' ? 'ASC' : 'DESC';
  const pageNum = Math.max(1, parseInt(page) || 1);
  const pageSize = Math.min(100, Math.max(1, parseInt(limit) || 20));
  const offset = (pageNum - 1) * pageSize;

  const countRow = db.prepare(`SELECT COUNT(*) as total FROM documents d ${where}`).get(...params);

  const docs = db.prepare(`
    SELECT d.*,
      o.name as owner_name, o.color as owner_color, o.icon as owner_icon,
      t.name as type_name, t.icon as type_icon,
      u.display_name as uploaded_by_name
    FROM documents d
    LEFT JOIN owners o ON d.owner_id = o.id
    LEFT JOIN document_types t ON d.type_id = t.id
    LEFT JOIN users u ON d.uploaded_by = u.id
    ${where}
    ORDER BY d.${sortCol} ${sortDir}
    LIMIT ? OFFSET ?
  `).all(...params, pageSize, offset);

  // Fetch tags for each document
  const tagStmt = db.prepare(`
    SELECT t.name FROM tags t
    JOIN document_tags dt ON t.id = dt.tag_id
    WHERE dt.document_id = ?
  `);

  const results = docs.map(doc => ({
    ...doc,
    tags: tagStmt.all(doc.id).map(t => t.name)
  }));

  // Log view activity for the requesting user
  logActivity(req.user.id, null, 'viewed', `${req.user.displayName} browsed documents`);

  res.json({
    documents: results,
    pagination: {
      page: pageNum,
      limit: pageSize,
      total: countRow.total,
      totalPages: Math.ceil(countRow.total / pageSize)
    }
  });
});

// Get single document
router.get('/:id', (req, res) => {
  const db = getDb();
  const doc = db.prepare(`
    SELECT d.*,
      o.name as owner_name, o.color as owner_color, o.icon as owner_icon,
      t.name as type_name, t.icon as type_icon,
      u.display_name as uploaded_by_name
    FROM documents d
    LEFT JOIN owners o ON d.owner_id = o.id
    LEFT JOIN document_types t ON d.type_id = t.id
    LEFT JOIN users u ON d.uploaded_by = u.id
    WHERE d.id = ?
  `).get(req.params.id);

  if (!doc) return res.status(404).json({ error: 'Document not found' });

  const tags = db.prepare(`
    SELECT t.name FROM tags t
    JOIN document_tags dt ON t.id = dt.tag_id
    WHERE dt.document_id = ?
  `).all(doc.id).map(t => t.name);

  // Log view
  logActivity(req.user.id, doc.id, 'viewed', `${req.user.displayName} viewed "${doc.title}"`);
  notifyUsers(req.user, 'viewed', `👁️ ${req.user.displayName} viewed "${doc.title}"`);

  res.json({ ...doc, tags });
});

// Update document metadata
router.patch('/:id', (req, res) => {
  const db = getDb();
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Document not found' });

  const fields = ['title', 'owner_id', 'type_id', 'status', 'document_date',
    'expiration_date', 'amount', 'vendor', 'notes'];
  const updates = [];
  const params = [];

  for (const field of fields) {
    if (req.body[field] !== undefined) {
      updates.push(`${field} = ?`);
      params.push(req.body[field] === '' ? null : req.body[field]);
    }
  }

  if (updates.length > 0) {
    updates.push("updated_at = datetime('now')");
    params.push(req.params.id);
    db.prepare(`UPDATE documents SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  }

  // Update tags if provided
  if (req.body.tags) {
    const tagList = typeof req.body.tags === 'string' ? JSON.parse(req.body.tags) : req.body.tags;
    db.prepare('DELETE FROM document_tags WHERE document_id = ?').run(req.params.id);
    applyTags(db, req.params.id, tagList);
  }

  logActivity(req.user.id, req.params.id, 'edited', `${req.user.displayName} edited "${doc.title}"`);
  notifyUsers(req.user, 'edited', `✏️ ${req.user.displayName} edited "${doc.title}"`);

  const updated = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  res.json(updated);
});

// Delete document
router.delete('/:id', (req, res) => {
  const db = getDb();
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Document not found' });

  // Delete files from disk
  const uploadBase = process.env.UPLOAD_PATH || path.join(__dirname, '../../data/files');
  const thumbBase = process.env.THUMBNAIL_PATH || path.join(__dirname, '../../data/thumbnails');

  try { fs.unlinkSync(path.join(uploadBase, doc.file_path)); } catch (e) {}
  try { if (doc.thumbnail_path) fs.unlinkSync(path.join(thumbBase, doc.thumbnail_path)); } catch (e) {}

  db.prepare('DELETE FROM documents WHERE id = ?').run(req.params.id);

  logActivity(req.user.id, null, 'deleted', `${req.user.displayName} deleted "${doc.title}"`);
  notifyUsers(req.user, 'deleted', `🗑️ ${req.user.displayName} deleted "${doc.title}"`);

  res.json({ deleted: true });
});

// Helper: apply tags to a document
function applyTags(db, documentId, tagNames) {
  const findTag = db.prepare('SELECT id FROM tags WHERE name = ?');
  const insertTag = db.prepare('INSERT INTO tags (id, name) VALUES (?, ?)');
  const linkTag = db.prepare('INSERT OR IGNORE INTO document_tags (document_id, tag_id) VALUES (?, ?)');

  for (const name of tagNames) {
    const trimmed = name.trim().toLowerCase();
    if (!trimmed) continue;

    let tag = findTag.get(trimmed);
    if (!tag) {
      const id = uuidv4();
      insertTag.run(id, trimmed);
      tag = { id };
    }
    linkTag.run(documentId, tag.id);
  }
}

module.exports = router;
